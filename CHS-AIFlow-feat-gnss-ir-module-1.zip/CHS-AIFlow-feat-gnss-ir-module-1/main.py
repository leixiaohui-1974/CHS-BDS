import cv2
import numpy as np
import os

# Import the custom modules
from src import data_acquisition
from src import geometric_correction
from src import wlr
from src import fvm

def main():
    """
    Main function to run the HydroVision-Edge analysis pipeline.
    """
    print("HydroVision-Edge: Python Prototype")
    print("------------------------------------")

    # --- 1. Configuration ---
    # NOTE: Replace with the actual path to your video file.
    video_path = "data/sample_video.mp4"

    # Check if the sample video exists.
    if not os.path.exists(video_path):
        print(f"Error: Sample video not found at '{video_path}'.")
        print("Please place a video file at that location or update the 'video_path' variable in main.py.")
        # As a fallback, create an empty file to indicate where it should go.
        if not os.path.exists("data"):
            os.makedirs("data")
        with open(video_path, "w") as f:
            f.write("This is a placeholder. Replace this file with your sample video (e.g., sample_video.mp4).\n")
        return

    # Load default configurations for analysis modules.
    # In a real application, these would be loaded from a config file.
    gcp_config = geometric_correction.get_default_gcp_config()
    wlr_roi = wlr.get_default_wlr_roi()

    # --- 2. Initialization ---
    print("Initializing modules...")
    # Load the video stream
    cap = data_acquisition.load_video(video_path)
    if cap is None:
        return # Error message is handled in the module

    # Get the perspective transformation matrix for geometric correction
    transform_matrix = geometric_correction.get_perspective_transform_matrix(
        gcp_config["src_points"], gcp_config["dst_points"]
    )

    # Initialize the Flow Velocity Measurement (FVM) processor
    fvm_processor = fvm.FlowVelocityMeasurement()

    print("Initialization complete. Starting video processing...")

    # --- 3. Main Processing Loop ---
    frame_count = 0
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("End of video stream.")
            break

        # --- 4. Analysis Pipeline ---

        # a) Water Level Recognition (on original frame)
        # This is done on the original, uncorrected frame, as the ROI is defined
        # for the camera's perspective.
        water_level = wlr.find_water_level(frame, wlr_roi)

        # b) Geometric Correction
        # Apply the perspective transform to get a top-down view for flow measurement.
        rectified_frame = geometric_correction.apply_perspective_transform(
            frame, transform_matrix, gcp_config["output_size"]
        )

        # c) Flow Velocity Measurement (on rectified frame)
        # FVM requires the orthorectified view to measure true surface velocity.
        velocity_vector = fvm_processor.process_frame(rectified_frame)

        # --- 5. Output Results ---
        # Print results every 10 frames to avoid flooding the console.
        if frame_count % 10 == 0:
            print(f"--- Frame {frame_count} ---")
            if water_level is not None:
                print(f"  Water Level (Y-coordinate): {water_level} pixels")
            else:
                print("  Water Level: Not detected")

            if fvm_processor.using_cpp:
                # C++ implementation returns a single float for velocity in m/s
                if velocity_vector is not None and velocity_vector > 0:
                    print(f"  Flow Velocity (m/s): {velocity_vector:.2f}")
                else:
                    print("  Flow Velocity: Not calculated")
            else:
                # Python fallback returns a tuple (vx, vy) in pixels/frame
                if velocity_vector:
                    vx, vy = velocity_vector
                    if vx != 0 or vy != 0:
                        print(f"  Flow Velocity (pixels/frame): vx={vx:.2f}, vy={vy:.2f}")
                    else:
                        print("  Flow Velocity: Not calculated")
                else:
                    print("  Flow Velocity: Not calculated")

        frame_count += 1

        # Optional: Display video feeds for debugging
        # To enable, uncomment the following lines.
        # cv2.imshow('Original Frame', frame)
        # cv2.imshow('Rectified Frame', rectified_frame)
        # if cv2.waitKey(1) & 0xFF == ord('q'):
        #     break

    # --- 6. Cleanup ---
    print("Processing finished. Cleaning up...")
    cap.release()
    # cv2.destroyAllWindows() # Uncomment if using imshow

if __name__ == "__main__":
    main()
