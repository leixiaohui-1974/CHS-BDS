# HydroVision-Edge: Real-time Video Hydrology Monitoring System

This project is a high-precision, real-time video-based hydrology monitoring system. It calculates water level and surface flow velocity from IP camera video streams.

This repository contains the Phase 1 implementation: a Python prototype to validate the core algorithms.

## Project Structure

- `main.py`: The main application script to run the analysis pipeline.
- `requirements.txt`: A list of Python dependencies required for this project.
- `src/`: A directory containing the core Python modules.
  - `data_acquisition.py`: Module for video capture.
  - `geometric_correction.py`: Module for orthorectification.
  - `wlr.py`: Module for Water Level Recognition.
  - `fvm.py`: Module for Flow Velocity Measurement.
- `data/`: A directory for sample videos and calibration data.
- `tests/`: A directory for unit tests.

## Phase 1: Python Prototype

The goal of this phase is to validate the following algorithms:
- **Geometric Correction:** Perspective transform based on Ground Control Points (GCPs).
- **Water Level Recognition (WLR):** Horizontal Intensity Projection method.
- **Flow Velocity Measurement (FVM):** LSPIV using Shi-Tomasi feature detection and Lucas-Kanade optical flow.

## Usage

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the application:**
   ```bash
   python main.py
   ```

## Building the C++ Module for Performance (Optional)

For improved performance, especially on embedded systems like the NVIDIA Jetson, this project includes a C++ implementation of the Flow Velocity Measurement (FVM) module. The Python code is designed to automatically use the C++ version if it is compiled.

### Prerequisites

To build the C++ module, you need a C++ compiler, CMake, and the full OpenCV library with development headers. The `opencv-python` package installed via pip is **not sufficient** as it often lacks the necessary C++ headers.

- **C++ Compiler:** A modern C++ compiler (e.g., g++).
- **CMake:** Version 3.10 or higher.
- **OpenCV:** The full development library.

On a Debian-based system (like Ubuntu), you can install the prerequisites with:
```bash
sudo apt-get update
sudo apt-get install build-essential cmake libopencv-dev
```

### Build Steps

1.  **Create a build directory:**
    ```bash
    mkdir build
    cd build
    ```

2.  **Run CMake to configure the project:**
    ```bash
    cmake ..
    ```

3.  **Compile the code:**
    ```bash
    make
    ```

This will produce a shared library file (e.g., `fvm_cpp.so`) inside the `src` directory. The application will then automatically detect and use this compiled module.
