import georinex.nav

print("--- Inspecting the georinex.nav submodule ---")
print(dir(georinex.nav))

print("\n--- Help for georinex.nav ---")
help(georinex.nav)
