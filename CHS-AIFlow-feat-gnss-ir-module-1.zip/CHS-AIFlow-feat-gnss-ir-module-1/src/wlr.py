import cv2
import numpy as np

def find_water_level(image, roi):
    """
    Finds the water level in a specific Region of Interest (ROI) of an image.

    This function implements the Horizontal Intensity Projection and Maximum
    Intensity Difference algorithm. It is designed to be robust against
    water ripples and lighting variations on a water gauge.

    Args:
        image (np.ndarray): The input image (video frame). It is expected to be
                            in BGR format as read by OpenCV.
        roi (tuple): A tuple defining the ROI as (x, y, w, h), where (x, y)
                     is the top-left corner and (w, h) are width and height.

    Returns:
        int: The absolute y-coordinate of the detected water level in the
             original image's coordinate system. Returns None if the ROI
             is invalid or the water level cannot be determined.
    """
    # 1. Validate and Extract the ROI
    x, y, w, h = roi
    if w <= 0 or h <= 0:
        print("Error: ROI width and height must be positive.")
        return None

    roi_image = image[y : y + h, x : x + w]

    if roi_image.size == 0:
        print("Error: ROI is outside the image boundaries or has zero size.")
        return None

    # 2. Convert the ROI to Grayscale
    # Intensity calculations are performed on a single channel.
    gray_roi = cv2.cvtColor(roi_image, cv2.COLOR_BGR2GRAY)

    # 3. Calculate Horizontal Intensity Projection
    # This computes the average intensity for each row of pixels in the grayscale ROI.
    # The result is a 1D array where each element is the mean brightness of a row.
    # axis=1 specifies that the mean is calculated across the horizontal axis (rows).
    horizontal_projection = np.mean(gray_roi, axis=1)

    if horizontal_projection.size < 2:
        print("Error: ROI is too small to calculate intensity differences.")
        return None

    # 4. Find the Maximum Intensity Difference
    # We calculate the difference between each consecutive element in the projection.
    # The largest difference corresponds to the sharpest change in brightness,
    # which is expected at the water line (interface between dry and wet gauge).
    intensity_diff = np.abs(np.diff(horizontal_projection))

    # Find the index of the maximum difference. This index corresponds to the row
    # number (within the ROI) where the water level is located.
    max_diff_index = np.argmax(intensity_diff)

    # 5. Return the Absolute Y-Coordinate
    # The calculated index is relative to the ROI, so we add the ROI's top
    # y-coordinate to get the position in the original image.
    water_level_y = y + max_diff_index

    return int(water_level_y)

# --- Example Usage (for demonstration and testing) ---

def get_default_wlr_roi():
    """
    Provides a default Region of Interest (ROI) for WLR demonstration.

    NOTE: This is a placeholder value and MUST be replaced with an actual
          ROI for a specific camera setup. The ROI should tightly bound
          the water gauge in the camera's view.
    """
    # A hypothetical ROI for a water gauge in a 1920x1080 frame.
    # (x, y, width, height)
    roi = (1250, 300, 150, 500)
    return roi
