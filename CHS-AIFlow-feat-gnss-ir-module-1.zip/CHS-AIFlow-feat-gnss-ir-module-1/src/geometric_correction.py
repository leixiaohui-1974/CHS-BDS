import cv2
import numpy as np

def get_perspective_transform_matrix(src_points, dst_points):
    """
    Calculates the perspective transformation matrix from source to destination points.

    This matrix is used to correct the perspective of the camera, creating a
    top-down (orthorectified) view of the scene. It should be calculated once
    during a calibration step.

    Args:
        src_points (np.ndarray): A NumPy array of 4 points in the source image.
                                 Shape: (4, 2), dtype: np.float32.
                                 Example: np.float32([[x1, y1], [x2, y2], [x3, y3], [x4, y4]])
        dst_points (np.ndarray): A NumPy array of 4 corresponding points in the
                                 destination (output) image.
                                 Shape: (4, 2), dtype: np.float32.

    Returns:
        np.ndarray: The 3x3 perspective transformation matrix.
    """
    if src_points.shape != (4, 2) or dst_points.shape != (4, 2):
        raise ValueError("Source and destination points must be NumPy arrays of shape (4, 2).")

    matrix = cv2.getPerspectiveTransform(src_points, dst_points)
    return matrix

def apply_perspective_transform(image, matrix, output_size):
    """
    Applies a perspective transform to an image using a transformation matrix.

    Args:
        image (np.ndarray): The input image (e.g., a video frame) to be transformed.
        matrix (np.ndarray): The 3x3 perspective transformation matrix from
                             get_perspective_transform_matrix.
        output_size (tuple): A tuple specifying the (width, height) of the output image.

    Returns:
        np.ndarray: The orthorectified image.
    """
    if matrix is None or matrix.shape != (3, 3):
        raise ValueError("A valid 3x3 transformation matrix must be provided.")

    # Warp the image using the calculated matrix and specified output size.
    rectified_image = cv2.warpPerspective(image, matrix, output_size)
    return rectified_image

# --- Example Usage (for demonstration and testing) ---
# In a real application, these values would come from a calibration process.

def get_default_gcp_config():
    """
    Provides a default set of Ground Control Points (GCPs) for demonstration.

    NOTE: These are placeholder values and MUST be replaced with actual,
          calibrated points for any real-world use case.
    """
    # Example source points from a hypothetical camera view (e.g., corners of a known rectangle on the ground)
    # These points form a trapezoid due to perspective.
    src_points = np.float32([
        [500, 400],  # Top-left corner
        [800, 400],  # Top-right corner
        [200, 700],  # Bottom-left corner
        [1100, 700]  # Bottom-right corner
    ])

    # Desired destination points to create a rectangular, top-down view.
    # The output size will be 1000x500 pixels.
    output_width = 1000
    output_height = 500
    dst_points = np.float32([
        [0, 0],                  # Corresponds to src_points[0]
        [output_width, 0],       # Corresponds to src_points[1]
        [0, output_height],      # Corresponds to src_points[2]
        [output_width, output_height] # Corresponds to src_points[3]
    ])

    return {
        "src_points": src_points,
        "dst_points": dst_points,
        "output_size": (output_width, output_height)
    }
