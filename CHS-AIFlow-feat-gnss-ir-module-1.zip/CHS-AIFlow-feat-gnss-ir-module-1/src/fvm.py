import cv2
import numpy as np

# We will attempt to import the C++ module, but fall back to the pure Python
# implementation if it's not available (e.g., not compiled yet).
try:
    from . import fvm_cpp
    CPP_AVAILABLE = True
except ImportError:
    print("Warning: C++ FVM module not found. Falling back to pure Python implementation.")
    CPP_AVAILABLE = False


class FlowVelocityMeasurement:
    """
    Measures water surface velocity.

    This class acts as a wrapper. If the C++ implementation is available, it
    will be used for performance. Otherwise, it falls back to a pure Python
    implementation.
    """

    def __init__(self):
        """
        Initializes the FVM processor.
        """
        if CPP_AVAILABLE:
            self.fvm_impl = fvm_cpp.FlowVelocityMonitor()
            self.is_cpp = True
        else:
            # These are the parameters from the original python implementation
            shi_tomasi_params = dict(maxCorners=200, qualityLevel=0.01, minDistance=10, blockSize=7)
            lk_params = dict(winSize=(15, 15), maxLevel=2, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
            self.fvm_impl = FlowVelocityMeasurement.PythonFVM(shi_tomasi_params, lk_params)
            self.is_cpp = False


    def process_frame(self, frame):
        """
        Processes a single video frame to calculate flow velocity.

        Args:
            frame (np.ndarray): The input video frame (orthorectified).

        Returns:
            If C++ is used: a float representing the velocity in m/s.
            If Python is used: a tuple (vx, vy) in pixels/frame.
        """
        if self.is_cpp:
            return self.fvm_impl.processFrame(frame)
        else:
            return self.fvm_impl.process_frame(frame)

    @property
    def using_cpp(self):
        return self.is_cpp


    # Keep the original Python implementation as a nested class for fallback.
    class PythonFVM:
        def __init__(self, shi_tomasi_params, lk_params):
            self.shi_tomasi_params = shi_tomasi_params
            self.lk_params = lk_params
            self.prev_gray = None
            self.prev_points = None

        def process_frame(self, frame):
            current_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            if self.prev_points is None or len(self.prev_points) == 0:
                self.prev_points = cv2.goodFeaturesToTrack(current_gray, mask=None, **self.shi_tomasi_params)
                self.prev_gray = current_gray
                if self.prev_points is None: return (0, 0)
                return (0, 0)

            current_points, status, err = cv2.calcOpticalFlowPyrLK(
                self.prev_gray, current_gray, self.prev_points, None, **self.lk_params
            )

            if current_points is not None:
                good_new = current_points[status == 1]
                good_old = self.prev_points[status == 1]
            else:
                self.prev_points = None
                self.prev_gray = current_gray
                return (0, 0)

            if len(good_new) < 5:
                self.prev_points = None
                self.prev_gray = current_gray
                return (0, 0)

            displacement_vectors = good_new - good_old
            median_vx = np.median(displacement_vectors[:, 0])
            median_vy = np.median(displacement_vectors[:, 1])

            self.prev_gray = current_gray.copy()
            self.prev_points = good_new.reshape(-1, 1, 2)

            return (median_vx, median_vy)
