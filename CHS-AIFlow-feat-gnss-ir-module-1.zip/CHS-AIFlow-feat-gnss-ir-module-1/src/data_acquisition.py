import cv2
import os

def load_video(video_path):
    """
    Loads a video from the specified file path.

    This function uses OpenCV to create a VideoCapture object from a video file.
    It performs checks to ensure the file exists and can be opened by OpenCV.

    Args:
        video_path (str): The full path to the video file.

    Returns:
        cv2.VideoCapture: An OpenCV VideoCapture object if the video is loaded successfully.
                          Returns None if the file does not exist or cannot be opened.
    """
    # Check if the video file exists at the given path.
    if not os.path.exists(video_path):
        print(f"Error: Video file not found at '{video_path}'")
        return None

    # Attempt to open the video file using OpenCV.
    cap = cv2.VideoCapture(video_path)

    # Check if the VideoCapture object was successfully opened.
    if not cap.isOpened():
        print(f"Error: Could not open video file '{video_path}'. It may be corrupt or in an unsupported format.")
        return None

    print(f"Successfully opened video file: {video_path}")
    return cap
