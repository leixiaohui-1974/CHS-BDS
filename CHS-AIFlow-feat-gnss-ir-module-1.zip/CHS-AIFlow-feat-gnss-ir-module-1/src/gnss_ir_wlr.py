"""
Module for Water Level Recognition (WLR) using GNSS Interferometric Reflectometry (GNSS-IR).

This module provides a complete pipeline to process GNSS Signal-to-Noise Ratio (SNR)
data from RINEX files to determine the vertical distance between a GNSS antenna and a
reflective surface (e.g., water). This is a common technique for water level monitoring.

The core methodology involves:
1.  Parsing RINEX observation and navigation files.
2.  Manually calculating satellite positions (azimuth, elevation) for each observation epoch.
3.  Detrending the Signal-to-Noise (SNR) data to isolate multipath oscillations.
4.  Applying the Lomb-Scargle Periodogram (LSP) to find the dominant frequency of the
    multipath signal.
5.  Calculating the reflector height from the dominant frequency and the signal's wavelength.

This script can be run from the command line to perform a full analysis on a given dataset.
"""
import argparse
import numpy as np
import pandas as pd
import georinex as gr
import xarray as xr
import traceback
from scipy.signal import lombscargle

# --- Constants ---
# WGS84 ellipsoid parameters
WGS84_A = 6378137.0  # semi-major axis
WGS84_E2 = 6.69437999014e-3  # first eccentricity squared

# GNSS signal wavelengths (in meters)
SPEED_OF_LIGHT = 299792458.0
WAVELENGTH_B1 = SPEED_OF_LIGHT / (1561.098e6)  # BeiDou B1
WAVELENGTH_L1 = SPEED_OF_LIGHT / (1575.42e6)   # GPS L1

# --- Geodetic Calculation Functions ---

def ecef2geodetic(x, y, z):
    """
    Convert Earth-Centered, Earth-Fixed (ECEF) coordinates to geodetic
    coordinates (latitude, longitude, height).

    Uses an iterative algorithm for high accuracy.

    Args:
        x (float): ECEF X-coordinate.
        y (float): ECEF Y-coordinate.
        z (float): ECEF Z-coordinate.

    Returns:
        tuple[float, float, float]: Geodetic latitude (deg), longitude (deg), and height (m).
    """
    p = np.sqrt(x**2 + y**2)
    lon = np.arctan2(y, x)

    lat = np.arctan2(z, p * (1 - WGS84_E2))
    h = 0
    for _ in range(5):
        n = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
        h = p / np.cos(lat) - n
        lat = np.arctan2(z, p * (1 - WGS84_E2 * n / (n + h)))

    n = WGS84_A / np.sqrt(1 - WGS84_E2 * np.sin(lat)**2)
    h = p / np.cos(lat) - n

    return np.rad2deg(lat), np.rad2deg(lon), h

def ecef_to_azel(sat_x, sat_y, sat_z, rec_x, rec_y, rec_z):
    """
    Calculate azimuth and elevation from satellite and receiver ECEF positions.

    Args:
        sat_x, sat_y, sat_z (float): Satellite ECEF coordinates.
        rec_x, rec_y, rec_z (float): Receiver ECEF coordinates.

    Returns:
        tuple[float, float]: Azimuth (deg) and elevation (deg).
    """
    lat, lon, _ = ecef2geodetic(rec_x, rec_y, rec_z)
    lat_rad = np.deg2rad(lat)
    lon_rad = np.deg2rad(lon)

    dx, dy, dz = sat_x - rec_x, sat_y - rec_y, sat_z - rec_z

    sin_lat, cos_lat = np.sin(lat_rad), np.cos(lat_rad)
    sin_lon, cos_lon = np.sin(lon_rad), np.cos(lon_rad)

    r = np.array([
        [-sin_lon, cos_lon, 0],
        [-sin_lat * cos_lon, -sin_lat * sin_lon, cos_lat],
        [cos_lat * cos_lon, cos_lat * sin_lon, sin_lat]
    ])

    enu = r @ np.array([dx, dy, dz])
    e, n, u = enu[0], enu[1], enu[2]

    az = np.rad2deg(np.arctan2(e, n))
    if az < 0:
        az += 360
    el = np.rad2deg(np.arcsin(u / np.sqrt(e**2 + n**2 + u**2)))

    return az, el

# --- Core Processing Functions ---

def extract_obs_data(obs_file_path, nav_file_path, satellite_id, constellation='G', signal_band='S1'):
    """
    Parses RINEX files and extracts data for a specific satellite.

    This function processes data epoch-by-epoch to robustly calculate
    satellite positions and handle missing or corrupt data in the ephemeris.

    Args:
        obs_file_path (str): Path to the RINEX observation file.
        nav_file_path (str): Path to the RINEX navigation file.
        satellite_id (str): Identifier of the satellite (e.g., 'G08').
        constellation (str): Constellation identifier ('G' for GPS).
        signal_band (str): RINEX code for the SNR observation.

    Returns:
        pd.DataFrame: DataFrame with 'snr', 'elevation', 'azimuth' columns,
                      filtered for elevation <= 30 degrees.
    """
    try:
        obs = gr.load(obs_file_path, use=constellation)
        nav = gr.rinexnav(nav_file_path, use=constellation)
    except Exception as e:
        print(f"Error loading RINEX files: {e}")
        return pd.DataFrame()

    rec_pos = obs.attrs.get('position')
    if rec_pos is None:
        print("Receiver position not found in observation file header.")
        return pd.DataFrame()

    if satellite_id not in obs.sv.values:
        print(f"Satellite {satellite_id} not found in observation data.")
        return pd.DataFrame()
    sat_obs = obs.sel(sv=satellite_id)

    times, elevations, azimuths, snr_values = [], [], [], []

    for t in sat_obs.time.values:
        snr_val = sat_obs[signal_band].sel(time=t).item()
        if pd.isna(snr_val):
            continue

        try:
            nav_epoch = nav.sel(sv=satellite_id).sel(time=t, method='nearest', tolerance='2h')
            if nav_epoch.isnull().to_array().any().item():
                continue
        except (KeyError, IndexError):
            continue

        try:
            nav_epoch_expanded = nav_epoch.expand_dims("time")
            nav_epoch_no_sv = nav_epoch_expanded.reset_coords('sv', drop=True)
            pos_tuple = gr.keplerian2ecef(nav_epoch_no_sv)
            sat_x, sat_y, sat_z = pos_tuple[0].item(), pos_tuple[1].item(), pos_tuple[2].item()
        except Exception:
            # print(f"Position calculation failed for {satellite_id} at {t}. Printing traceback:")
            # traceback.print_exc()
            continue

        az, el = ecef_to_azel(sat_x, sat_y, sat_z, rec_pos[0], rec_pos[1], rec_pos[2])
        times.append(t)
        elevations.append(el)
        azimuths.append(az)
        snr_values.append(snr_val)

    if not times:
        print(f"No valid data points found for {satellite_id}.")
        return pd.DataFrame()

    df = pd.DataFrame({
        'snr': snr_values,
        'elevation': elevations,
        'azimuth': azimuths
    }, index=pd.to_datetime(times))

    df = df[df['elevation'] <= 30]
    return df

def detrend_snr(df, poly_degree=2):
    """
    Detrends the SNR data by fitting and removing a low-order polynomial.

    Args:
        df (pd.DataFrame): DataFrame containing 'snr' and 'elevation'.
        poly_degree (int): The degree of the polynomial to fit.

    Returns:
        pd.DataFrame: DataFrame with added 'sin_elevation' and 'snr_residual'.
    """
    if df.empty or 'elevation' not in df or 'snr' not in df:
        return pd.DataFrame()

    df['sin_elevation'] = np.sin(np.deg2rad(df['elevation']))
    poly_coeffs = np.polyfit(df['sin_elevation'], df['snr'], poly_degree)
    snr_trend = np.polyval(poly_coeffs, df['sin_elevation'])
    df['snr_residual'] = df['snr'] - snr_trend
    return df

def calculate_reflector_height(df, wavelength, min_h=0.5, max_h=10.0):
    """
    Calculates reflector height using Lomb-Scargle Periodogram on SNR data.

    Args:
        df (pd.DataFrame): DataFrame with 'sin_elevation' and 'snr_residual'.
        wavelength (float): Wavelength of the GNSS signal.
        min_h (float): Minimum expected reflector height (m).
        max_h (float): Maximum expected reflector height (m).

    Returns:
        float | None: Calculated reflector height (m), or None if no peak is found.
    """
    if df.empty or 'sin_elevation' not in df or 'snr_residual' not in df:
        return None

    min_freq = 2 * min_h / wavelength
    max_freq = 2 * max_h / wavelength
    freqs = np.linspace(min_freq, max_freq, len(df) * 5)

    x = df['sin_elevation'].values
    y = df['snr_residual'].values
    power = lombscargle(x, y, freqs, normalize=True)

    peak_index = np.argmax(power)
    peak_power = power[peak_index]

    if peak_power < 0.2:
        print("No significant peak found in the periodogram.")
        return None

    peak_freq = freqs[peak_index]
    reflector_height = peak_freq * wavelength / 2
    return reflector_height

# --- Main Execution Block ---

def main():
    """Main function to run the GNSS-IR analysis from the command line."""
    parser = argparse.ArgumentParser(
        description="Calculate reflector height from RINEX files using GNSS-IR."
    )
    parser.add_argument("obs_file", help="Path to the RINEX observation file.")
    parser.add_argument("nav_file", help="Path to the RINEX navigation file.")
    parser.add_argument("--sv", help="Satellite vehicle ID (e.g., 'G08')", required=True)
    parser.add_argument("--band", help="Signal band (e.g., 'S1')", default='S1')
    parser.add_argument("--min_h", type=float, default=0.5, help="Minimum reflector height (m).")
    parser.add_argument("--max_h", type=float, default=10.0, help="Maximum reflector height (m).")
    args = parser.parse_args()

    print("--- Starting GNSS-IR Processing ---")

    # For now, we assume GPS L1 signal
    wavelength = WAVELENGTH_L1
    print(f"Assuming GPS L1 signal with wavelength {wavelength:.4f} m")

    # 1. Extract data
    print(f"Step 1: Extracting data for {args.sv}...")
    raw_df = extract_obs_data(
        args.obs_file, args.nav_file, args.sv, signal_band=args.band
    )
    if raw_df.empty:
        print("Failed to extract data. Aborting.")
        return
    print(f"   ...Success. Found {len(raw_df)} valid data points.")

    # 2. Detrend SNR
    print("\nStep 2: Detrending SNR data...")
    detrended_df = detrend_snr(raw_df)
    if detrended_df.empty:
        print("Failed to detrend data. Aborting.")
        return
    print("   ...Success.")

    # 3. Calculate reflector height
    print("\nStep 3: Calculating reflector height...")
    height = calculate_reflector_height(
        detrended_df, wavelength, min_h=args.min_h, max_h=args.max_h
    )

    if height is not None:
        print("\n--- ANALYSIS COMPLETE ---")
        print(f"Calculated Reflector Height: {height:.2f} meters")
    else:
        print("\n--- ANALYSIS FAILED ---")
        print("Could not determine a significant reflector height.")

if __name__ == "__main__":
    main()
