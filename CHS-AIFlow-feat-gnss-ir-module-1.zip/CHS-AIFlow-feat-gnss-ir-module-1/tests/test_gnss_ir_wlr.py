import pytest
import pandas as pd
from src.gnss_ir_wlr import (
    extract_obs_data,
    detrend_snr,
    calculate_reflector_height,
    WAVELENGTH_L1
)

# --- Test Configuration ---
OBS_FILE = 'data/auckland_obs.rnx.Z'
NAV_FILE = 'data/auckland_nav.rnx.Z'
SATELLITE = 'G08'
SIGNAL_BAND = 'S1'
WAVELENGTH = WAVELENGTH_L1
MIN_HEIGHT = 0.5  # meters
MAX_HEIGHT = 2.5  # meters

@pytest.fixture(scope="module")
def processed_data():
    """
    Pytest fixture to run the data extraction and pre-processing once for all tests.
    """
    # 1. Extract data
    df = extract_obs_data(
        obs_file_path=OBS_FILE,
        nav_file_path=NAV_FILE,
        satellite_id=SATELLITE,
        constellation='G',
        signal_band=SIGNAL_BAND
    )
    assert not df.empty, f"Failed to extract data for {SATELLITE}"

    # 2. Detrend SNR
    df = detrend_snr(df)
    assert not df.empty, "Failed to detrend data"
    assert 'snr_residual' in df.columns

    return df

def test_full_gnss_ir_pipeline(processed_data):
    """
    Tests the full GNSS-IR processing pipeline from data extraction to height calculation.
    """
    # 3. Calculate reflector height
    height = calculate_reflector_height(
        processed_data,
        wavelength=WAVELENGTH,
        min_h=MIN_HEIGHT,
        max_h=MAX_HEIGHT
    )

    # Assert that a valid height was calculated
    assert height is not None, "Calculated height should not be None"

    # Assert that the height is within the plausible physical range
    assert MIN_HEIGHT <= height <= MAX_HEIGHT, f"Height {height:.2f} is outside the expected range"

    print(f"\nTest successful: Calculated reflector height is {height:.2f} m, which is within the expected range.")

def test_data_extraction_failure():
    """
    Tests that data extraction fails gracefully for a non-existent satellite.
    """
    df = extract_obs_data(
        obs_file_path=OBS_FILE,
        nav_file_path=NAV_FILE,
        satellite_id='G99', # A satellite that does not exist
        constellation='G',
        signal_band=SIGNAL_BAND
    )
    assert df.empty, "Expected empty DataFrame for a non-existent satellite"
