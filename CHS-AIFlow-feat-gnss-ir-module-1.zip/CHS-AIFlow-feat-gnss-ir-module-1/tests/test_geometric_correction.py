import unittest
import numpy as np

# Add the project root to the path to allow importing src modules
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.geometric_correction import get_perspective_transform_matrix, apply_perspective_transform, get_default_gcp_config

class TestGeometricCorrection(unittest.TestCase):

    def test_transform_execution_and_output_shape(self):
        """
        Tests that the perspective transform functions execute without error and
        produce an output image of the correct shape.
        """
        # 1. Get the default GCP configuration
        gcp_config = get_default_gcp_config()
        src_points = gcp_config["src_points"]
        dst_points = gcp_config["dst_points"]
        output_size = gcp_config["output_size"] # (width, height)

        # 2. Create a dummy input image that is large enough to contain the source points
        # The default source points are within a 1280x720 frame.
        input_image = np.zeros((720, 1280, 3), dtype=np.uint8)

        # 3. Calculate the transformation matrix
        matrix = get_perspective_transform_matrix(src_points, dst_points)
        self.assertIsNotNone(matrix, "Transformation matrix should not be None.")
        self.assertEqual(matrix.shape, (3, 3), "Matrix should be 3x3.")

        # 4. Apply the transformation
        rectified_image = apply_perspective_transform(input_image, matrix, output_size)
        self.assertIsNotNone(rectified_image, "Rectified image should not be None.")

        # 5. Assert the output shape is correct
        # Note: OpenCV shape is (height, width)
        expected_height, expected_width = output_size[1], output_size[0]
        self.assertEqual(rectified_image.shape[0], expected_height, "Output image height is incorrect.")
        self.assertEqual(rectified_image.shape[1], expected_width, "Output image width is incorrect.")

if __name__ == '__main__':
    unittest.main()
