import unittest
import numpy as np
import cv2

# Add the project root to the path to allow importing src modules
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.wlr import find_water_level

class TestWaterLevelRecognition(unittest.TestCase):

    def test_find_water_level_on_synthetic_image(self):
        """
        Tests the find_water_level function with a perfect synthetic image.
        """
        # 1. Create a synthetic image
        # Image is 200px high, 100px wide.
        # The top 100 rows are white (255), representing the dry gauge.
        # The bottom 100 rows are black (0), representing the water.
        # The water level is exactly at the boundary, y=100.
        height, width = 200, 100
        water_line_y = 100

        image = np.zeros((height, width, 3), dtype=np.uint8)
        image[0:water_line_y, :] = [255, 255, 255] # White top
        image[water_line_y:, :] = [0, 0, 0]       # Black bottom

        # 2. Define the ROI to be the entire image
        roi = (0, 0, width, height)

        # 3. Call the function to find the water level
        detected_level = find_water_level(image, roi)

        # 4. Assert the result
        # The np.diff operation calculates the difference between adjacent elements.
        # The maximum difference will be at the index just before the change.
        # So, for a change at index 100, argmax(diff) will return 99.
        expected_level = water_line_y - 1

        self.assertIsNotNone(detected_level, "The function should detect a water level.")
        self.assertEqual(expected_level, detected_level,
                         f"Detected water level should be {expected_level}, but was {detected_level}.")

if __name__ == '__main__':
    unittest.main()
