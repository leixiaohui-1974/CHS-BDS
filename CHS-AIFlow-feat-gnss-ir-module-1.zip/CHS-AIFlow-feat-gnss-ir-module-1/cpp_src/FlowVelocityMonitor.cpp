#include "FlowVelocityMonitor.h"
#include <iostream>
#include <algorithm>
#include <cmath>

// Helper function: calculate median
float FlowVelocityMonitor::calculate_median(std::vector<float>& v) {
    if (v.empty()) return 0.0f;
    size_t n = v.size() / 2;
    std::nth_element(v.begin(), v.begin() + n, v.end());
    return v[n];
}

void FlowVelocityMonitor::refresh_features(const cv::Mat& gray) {
    cv::goodFeaturesToTrack(gray, prev_points_, 150, 0.3, 10, cv::Mat(), 7);
}

FlowVelocityMonitor::FlowVelocityMonitor()
    : term_criteria_(cv::TermCriteria::COUNT | cv::TermCriteria::EPS, 10, 0.03) {}

float FlowVelocityMonitor::processFrame(const cv::Mat& current_frame) {
    cv::Mat current_gray;
    cv::cvtColor(current_frame, current_gray, cv::COLOR_BGR2GRAY);

    if (prev_gray_.empty()) {
        current_gray.copyTo(prev_gray_);
        refresh_features(current_gray);
        return 0.0f;
    }

    if (prev_points_.size() < 20) {
        refresh_features(current_gray);
         if (prev_points_.empty()) {
            current_gray.copyTo(prev_gray_);
            return 0.0f;
        }
    }

    std.vector<cv::Point2f> current_points;
    std::vector<uchar> status;
    std::vector<float> err;

    cv::calcOpticalFlowPyrLK(prev_gray_, current_gray, prev_points_, current_points,
                             status, err, cv::Size(21, 21), 3, term_criteria_);

    std::vector<float> displacements;
    std::vector<cv::Point2f> tracked_points;

    for (size_t i = 0; i < status.size(); ++i) {
        if (status[i]) {
            tracked_points.push_back(current_points[i]);
            float dx = current_points[i].x - prev_points_[i].x;
            float dy = current_points[i].y - prev_points_[i].y;
            float displacement = std::sqrt(dx * dx + dy * dy);
            displacements.push_back(displacement);
        }
    }

    if (displacements.empty()) {
        current_gray.copyTo(prev_gray_);
        prev_points_.clear();
        return 0.0f;
    }

    float median_displacement = calculate_median(displacements);

    float velocity_mps = median_displacement * METERS_PER_PIXEL * FRAME_RATE;

    prev_gray_ = current_gray.clone();
    prev_points_ = tracked_points;

    return velocity_mps;
}
