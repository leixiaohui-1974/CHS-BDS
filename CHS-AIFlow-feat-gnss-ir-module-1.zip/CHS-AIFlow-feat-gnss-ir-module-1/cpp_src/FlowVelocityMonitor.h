#ifndef FLOW_VELOCITY_MONITOR_H
#define FLOW_VELOCITY_MONITOR_H

#include <opencv2/opencv.hpp>
#include <vector>

// Configuration parameters (should be configurable)
const float METERS_PER_PIXEL = 0.01f;
const float FRAME_RATE = 30.0f;

class FlowVelocityMonitor {
private:
    cv::Mat prev_gray_;
    std::vector<cv::Point2f> prev_points_;
    cv::TermCriteria term_criteria_;

    void refresh_features(const cv::Mat& gray);
    static float calculate_median(std::vector<float>& v);

public:
    FlowVelocityMonitor();
    float processFrame(const cv::Mat& current_frame);
};

#endif // FLOW_VELOCITY_MONITOR_H
