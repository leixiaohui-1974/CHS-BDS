#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>
#include "FlowVelocityMonitor.h"
#include <opencv2/opencv.hpp>


namespace py = pybind11;

// A helper function to convert py::array to cv::Mat
cv::Mat array_to_mat(py::array b) {
    py::buffer_info info = b.request();
    if (info.format != py::format_descriptor<unsigned char>::format() || info.ndim != 3) {
        throw std::runtime_error("Incompatible buffer format!");
    }
    return cv::Mat(info.shape[0], info.shape[1], CV_8UC3, info.ptr);
}


PYBIND11_MODULE(fvm_cpp, m) {
    m.doc() = "Python bindings for the C++ Flow Velocity Monitor";

    py::class_<FlowVelocityMonitor>(m, "FlowVelocityMonitor")
        .def(py::init<>())
        .def("processFrame", [](FlowVelocityMonitor &self, py::array frame) {
            cv::Mat mat = array_to_mat(frame);
            return self.processFrame(mat);
        }, "Processes a frame and returns the velocity",
             py::arg("current_frame"));
}
